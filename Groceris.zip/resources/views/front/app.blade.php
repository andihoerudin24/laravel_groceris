   @include('front.header')
           @yield('content')
   @include('front.footer')