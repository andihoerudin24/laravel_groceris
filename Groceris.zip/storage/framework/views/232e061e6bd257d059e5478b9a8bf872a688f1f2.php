    <div class="form-group">
        <label for="squareInput">Name Products</label>
       <?php echo Form::select('id_product',App\Products::pluck('name_product','id')->all(),null, ['class'=>'form-control']); ?>

    </div>
     <?php if($errors->has('id_product')): ?>
         <div class="alert alert-danger">
           <?php echo e($errors->first('id_product')); ?>

         </div>
     <?php endif; ?>
     <div class="form-group">
            <label for="squareInput">name categories</label>
       <?php echo Form::select('id_categories',App\Categories::pluck('nama_kategori','id'),null, ['class'=>$errors->has('id_categories') ? 'form-control is-invalid' : 'form-control']); ?>


    </div>
    <?php if($errors->has('id_categories')): ?>
        <div class="alert alert-danger">
        <?php echo e($errors->first('id_categories')); ?>

        </div>
   <?php endif; ?>
    <div class="form-group">
        <label for="squareInput">name buyer</label>
        <?php echo Form::select('id_user',App\User::pluck('name','id'),null, ['class'=>$errors->has('id_user') ? 'form-control is-invalid' : 'form-control','readonly','block']); ?>

  </div>
    <?php if($errors->has('id_user')): ?>
        <div class="alert alert-warning">
          <?php echo e($errors->first('id_user')); ?>

        </div>
    <?php endif; ?>

    <div class="form-group">
        <label for="squareInput">Qty</label>
        <?php echo Form::number('qty',null,['class'=>'form-control','readonly']); ?>

  </div>

  <div class="form-group">
        <label for="squareInput">Order Total</label>

     <?php echo Form::select('status',['0' =>'unprocessed', '1' => 'been processed'],null,['class'=>'form-control']); ?>


</div>
