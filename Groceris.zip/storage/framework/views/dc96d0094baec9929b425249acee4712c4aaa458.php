    <div class="form-group">
        <label for="squareInput">Name</label>
      <?php echo Form::text('name',null, ['class'=>$errors->has('name') ? 'form-control is-invalid' : 'form-control','placeholder'=>'name products','required' ]); ?>

    </div>
     <?php if($errors->has('name')): ?>
         <div class="alert alert-danger">
           <?php echo e($errors->first('name')); ?>

         </div>
     <?php endif; ?>
     <div class="form-group">
            <label for="squareInput">Email</label>
          <?php echo Form::email('email',null, ['class'=>$errors->has('email') ? 'form-control is-invalid' : 'form-control','placeholder'=>'email','required' ]); ?>

    </div>
    <?php if($errors->has('email')): ?>
        <div class="alert alert-danger">
        <?php echo e($errors->first('email')); ?>

        </div>
   <?php endif; ?>
    <div class="form-group">
        <label for="squareInput">Phone</label>
        <?php echo Form::number('phone',null, ['class'=>$errors->has('phone') ? 'form-control is-invalid' : 'form-control','placeholder'=>'phone','required' ]); ?>

    </div>
    <?php if($errors->has('phone')): ?>
        <div class="alert alert-warning">
          <?php echo e($errors->first('phone')); ?>

        </div>
    <?php endif; ?>
  <div class="form-group">
        <label for="squareInput">City</label>
      <?php echo Form::text('city',null, ['class'=>$errors->has('city') ? 'form-control is-invalid' : 'form-control','placeholder'=>'city','required' ]); ?>

  </div>
  <?php if($errors->has('city')): ?>
    <div class="alert alert-warning">
        <?php echo e($errors->first('city')); ?>

    </div>
  <?php endif; ?>

  <div class="form-group">
    <label for="squareInput">Country</label>
  <?php echo Form::text('country',null, ['class'=>$errors->has('country') ? 'form-control is-invalid' : 'form-control','placeholder'=>'country','required' ]); ?>

</div>
     <?php if($errors->has('country')): ?>
            <div class="alert alert-warning">
                <?php echo e($errors->first('country')); ?>

            </div>
     <?php endif; ?>

  <div class="form-group">
    <label for="squareInput">Postcode</label>
  <?php echo Form::text('postcode',null, ['class'=>$errors->has('postcode') ? 'form-control is-invalid' : 'form-control','placeholder'=>'postcode','required' ]); ?>

</div>
     <?php if($errors->has('postcode')): ?>
            <div class="alert alert-warning">
                <?php echo e($errors->first('postcode')); ?>

            </div>
     <?php endif; ?>

  <div class="form-group">
    <label for="squareInput">Payment</label>
  <?php echo Form::text('payment',null, ['class'=>$errors->has('payment') ? 'form-control is-invalid' : 'form-control','placeholder'=>'payment','required' ]); ?>

</div>
     <?php if($errors->has('payment')): ?>
            <div class="alert alert-warning">
                <?php echo e($errors->first('payment')); ?>

            </div>
     <?php endif; ?>
  <div class="form-group">
        <label for="squareInput">Notes</label>
       <?php echo Form::textarea('notes',null,['class'=>$errors->has('notes') ? 'form-control is-invalid' : 'form-control']); ?>

 </div>
 <?php if($errors->has('notes')): ?>
    <div class="alert alert-info">
        <?php echo e($errors->first('notes')); ?>

    </div>
 <?php endif; ?>
