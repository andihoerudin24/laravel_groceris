<?php $__env->startSection('content'); ?>
<div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title">Add New Products</div>
            </div>
            <div class="card-body">
              <?php echo Form::open(['route'=>'products.store','method'=>'POST']); ?>


                    <?php echo $__env->make('admin.products._form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
             </div>
            <div class="card-action">
                <button type="submit" class="btn btn-success">Submit</button>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-danger">Cancel</a>
            </div>
            <?php echo Form::close(); ?>

        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('assets-bottom'); ?>
<script src="<?php echo e(asset('vendor/laravel-filemanager/js/lfm.js')); ?>"></script>
<script>
  $(document).ready( function () {
      $('#lfm').filemanager('image');
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>