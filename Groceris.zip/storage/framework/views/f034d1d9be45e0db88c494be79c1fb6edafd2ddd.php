<?php $__env->startSection('content'); ?>
<div id="page-content" class="page-content">
    <div class="banner">
        <div class="jumbotron jumbotron-bg text-center rounded-0" style="background-image: url('<?php echo e(asset('assets/img/bg-header.jpg')); ?>');">
            <div class="container">
                <h1 class="pt-5">
                   <?php echo e($products->name_product); ?>

                </h1>
                <p class="lead">
                    Save time and leave the groceries to us.
                </p>
            </div>
        </div>
    </div>
    <?php echo Form::open(['shop.update',$products->id,'method'=>'PUT']); ?>

    <?php echo Form::hidden('name_products',$products->name_product); ?>

    <?php echo Form::hidden('order_total',$products->price); ?>

    <?php echo Form::hidden('foto',$products->foto); ?>




    <div class="product-detail">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="slider-zoom">
                        <img class="cloudzoom" alt="Detail Zoom thumbs image" id="zoom1" src="<?php echo e($products->foto); ?>" data-cloudzoom='zoomPosition:"inside", autoInside: true, zoomOffsetX:0' style="width: 100%;">
                    </div>
                </div>
                <div class="col-sm-6">
                    <p>
                        <strong>Overview</strong><br>
                     <?php echo e($products->deskripsi); ?>

                    </p>
                    <div class="row">
                        <div class="col-sm-6">
                            <p>
                                <strong>Price</strong> (/Pack)<br>
                                <span class="price">Rp <?php echo e($products->price); ?></span>
                                <span class="old-price">Rp <?php echo e($products->price); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6 text-right">
                            <p>
                                <span class="stock available">In Stock: <?php echo e($products->stock); ?></span>
                            </p>
                        </div>
                    </div>
                    <p class="mb-1">
                        <strong>Quantity</strong>
                    </p>
                    <div class="row">
                        <div class="col-sm-5">
                            <input class="vertical-spin" type="text" data-bts-button-down-class="btn btn-primary" data-bts-button-up-class="btn btn-primary"  name="qty">
                        </div>
                        <div class="col-sm-6"><span class="pt-1 d-inline-block">Pack (250 gram)</span></div>
                    </div>



                    <button type="submit" class="mt-3 btn btn-primary btn-lg">
                        <i class="fa fa-shopping-basket"></i> Add to Cart
                    </button>
               <?php echo Form::close(); ?>

          </div>
            </div>
        </div>
    </div>

    <section id="related-product">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="title">Related Products</h2>
                    <div class="product-carousel owl-carousel">
                            <?php $__currentLoopData = \DB::table('products')->limit(5)->inRandomOrder()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                    <div class="card card-product">
                                        <div class="card-ribbon">
                                            <div class="card-ribbon-container right">
                                                <span class="ribbon ribbon-primary">SPECIAL</span>
                                            </div>
                                        </div>
                                        <div class="card-badge">
                                            <div class="card-badge-container left">
                                                <span class="badge badge-default">
                                                    Until 2018
                                                </span>
                                                <span class="badge badge-primary">
                                                    20% OFF
                                                </span>
                                            </div>
                                            <img src="<?php echo e($post->foto); ?>" alt="Card image 2" class="card-img-top">
                                        </div>
                                        <div class="card-body">
                                            <h4 class="card-title">
                                                <a href="detail-product.html"><?php echo e($post->name_product); ?></a>
                                            </h4>
                                            <div class="card-price">
                                                <span class="discount">Rp. 300</span>
                                                <span class="reguler">Rp. <?php echo e($post->price); ?></span>
                                            </div>
                                            <a href="<?php echo e(route('Shop.show',$post->id)); ?>" class="btn btn-block btn-primary">
                                                Add to Cart
                                            </a>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>