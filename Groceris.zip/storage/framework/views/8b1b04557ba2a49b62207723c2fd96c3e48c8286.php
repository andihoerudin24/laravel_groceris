<!DOCTYPE html>
<html>
<head>
    <title>Freshcery | Groceries Organic Store</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fonts/sb-bistro/sb-bistro.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/fonts/font-awesome/font-awesome.css')); ?>" rel="stylesheet" type="text/css">

    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/packages/bootstrap/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/packages/o2system-ui/o2system-ui.css')); ?>">
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/packages/owl-carousel/owl-carousel.css')); ?>">
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/packages/cloudzoom/cloudzoom.css')); ?>">
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/packages/thumbelina/thumbelina.css')); ?>">
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/packages/bootstrap-touchspin/bootstrap-touchspin.css')); ?>">
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/theme.css')); ?>">

</head>
<body>
    <div class="page-header">
        <!--=============== Navbar ===============-->
        <nav class="navbar fixed-top navbar-expand-md navbar-dark bg-transparent" id="page-navigation">
            <div class="container">
                <!-- Navbar Brand -->
                <a href="index.html" class="navbar-brand">
                    <img src="<?php echo e(asset('assets/img/logo/logo.png')); ?>" alt="">
                </a>

                <!-- Toggle Button -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarcollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarcollapse">
                    <!-- Navbar Menu -->
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a href="<?php echo e(route('Shop.index')); ?>" class="nav-link">Shop</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('register')); ?>" class="nav-link">Register</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('enter')); ?>" class="nav-link">Login</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <div class="avatar-header"><img src="<?php echo e(asset('assets/img/logo/avatar.jpg')); ?>"></div>
                                <?php if(empty(Auth::user()->name)): ?>
                                       Hi Buyer
                                <?php else: ?>
                                     <?php echo e(Auth::user()->name); ?>

                                <?php endif; ?>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('transaksihistory')); ?>">Transactions History</a>
                                <a class="dropdown-item" href="<?php echo e(route('setting')); ?>">Settings</a>
                            </div>
                          </li>
                        <li class="nav-item dropdown">
                            <a href="javascript:void(0)" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                <i class="fa fa-shopping-basket"></i>
                                <span class="badge badge-primary">

                                    <?php if(!Auth::user()): ?>
                                    <?php echo e(Cart::getTotalQuantity()); ?>

                                    <?php else: ?>
                                     <?php  $cart=Auth::user()->id; ?>
                                      <?php echo e(Cart::session($cart)->getTotalQuantity()); ?>

                                    <?php endif; ?>
                                </span>
                            </a>
                            <div class="dropdown-menu shopping-cart">
                                <ul>
                                    <li>
                                        <div class="drop-title">Your Cart</div>
                                    </li>
                                    <li>
                                        <div class="shopping-cart-list">
                                            <?php if(!Auth::user()): ?>
                                            <?php $__currentLoopData = Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="media">
                                                 <img class="d-flex mr-3" src="<?php echo e($item->attributes->foto); ?>" width="60">
                                                 <div class="media-body">
                                                     <h5><a href="javascript:void(0)"><?php echo e($item->name); ?></a></h5>
                                                     <p class="price">
                                                         <span class="discount text-muted">Rp. 700</span>
                                                         <span>Rp. <?php echo e($item->price); ?></span>
                                                     </p>
                                                     <p class="text-muted">Qty: <?php echo e($item->quantity); ?></p>
                                                 </div>
                                             </div>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <?php else: ?>
                                         <?php $userId =Auth::user()->id; ?>
                                         <?php $__currentLoopData = Cart::session($userId)->getContent($userId); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <div class="media">
                                                <img class="d-flex mr-3" src="<?php echo e($item->attributes->foto); ?>" width="60">
                                                <div class="media-body">
                                                    <h5><a href="javascript:void(0)"><?php echo e($item->name); ?></a></h5>
                                                    <p class="price">
                                                        <span class="discount text-muted">Rp. 700</span>
                                                        <span>Rp. <?php echo e($item->price); ?></span>
                                                    </p>
                                                    <p class="text-muted">Qty: <?php echo e($item->quantity); ?></p>
                                                </div>
                                            </div>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php endif; ?>
                                     </div>
                                    </li>
                                    <li>
                                        <div class="drop-title d-flex justify-content-between">
                                            <span>Total:</span>
                                            <span class="text-primary"><strong>Rp. <?php echo e(Cart::getSubTotal()); ?></strong></span>
                                        </div>
                                    </li>
                                    <li class="d-flex justify-content-between pl-3 pr-3 pt-3">
                                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-default">View Cart</a>
                                        <a href="<?php echo e(route('chekout')); ?>" class="btn btn-primary">Checkout</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>

            </div>
        </nav>
    </div>