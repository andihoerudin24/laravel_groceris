<?php $__env->startSection('assets-top'); ?>
<link href="<?php echo e(asset('admin/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">Data Categories</div>
        <?php if(session('sukses')): ?>
            <div class="alert alert-info">
                <?php echo e(session('sukses')); ?>

            </div>
         <?php elseif(session('delete')): ?>
          <div class="alert alert-danger">
             <?php echo e(session('delete')); ?>

          </div>
         <?php elseif(session('update')): ?>
         <div class="alert alert-success">
           <?php echo e(session('update')); ?>

         </div>
       <?php endif; ?>
</div>
    <div class="card-body">
        <div class="card-sub">
           <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-danger btn-sm">Tambah data</a>
        </div>
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>No</th>
                <th>Name Categories</th>
                <th>Picture</th>
                <th>Deskription</th>
                <th></th>
             </tr>
            </thead>
            <tfoot>
               <tr>
                <th>No</th>
                <th>Name Categories</th>
                <th>Picture</th>
                <th>Deskription</th>
                <th></th>
               </tr>
            </tfoot>
            <tbody>

            </tbody>
          </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('assets-bottom'); ?>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo e(asset('admin/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Responsive examples -->
    <script src="<?php echo e(asset('admin/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/datatables/responsive.bootstrap4.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $("#dataTable").DataTable({
                processing :true,
                serverSide :true,
                ajax       :"<?php echo e(route('api.datatable.categories')); ?>",
                columns :[
                    {data: 'DT_Row_Index',   orderable: false, searchable: false},
                    {data: 'nama_kategori',   name:'nama_kategori'},
                    {data: 'foto',            name:'foto'},
                    {data: 'deskripsi',       name:'deskripsi'},
                    {data: 'action',         name: 'action', orderable:false, seacrhable:false},
                 ]
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>